package CC_221047010;

import java.util.Scanner;

public class MyEcommclass {
	
	   public static void main(String[] args) 
	   {
	        Ecomm_operations a1=new Ecomm_operations();
	        System.out.println("Please enter your choice 1 to Add Product,2 to View Product,3 to Update Product");
	        Scanner sc=new Scanner(System.in);
	        int n=sc.nextInt();
	        if(n==1) 
	        {
	        a1.addProduct();
	        a1.viewProdut();
	        }
	        if(n==2) 
	        {
	        a1.viewProdut();
	        }
	        if(n==3) 
	        {
	        a1.updateProduct();
	        }
	    }
	}

